import React, { Component } from 'react'

export class ADD_CONTACTS extends Component
{
	state =
	{
		first_name: '',
		last_name: '',
		phone_num: '',
		email_num: '',
	}
	render()
	{
		// console helps me check that our object is being modified
		// console.log(this.state.first_name);
		// LOOK UP multiple forms with multiple inputs
		console.log("jjjjjjjjjjjjjjjj")
		return (
			<form onSubmit={this.on_submit} style={{ display: 'flex'}}>
			<div className = "flex" style={get_style}>
				<div>
						<div style={div_style}>
							<input
								type="text"
								name="first_name"
								style={{ flex: '10', padding: '10px', width: "30vw"}}
								placeholder="first name ..."
								value={this.state.first_name}
								onChange={this.changing}
							/>
						</div>
						<div style={div_style}>
							<input
								type="text"
								name="last_name"
								style={{ flex: '10', padding: '10px', width: "30vw"}}
								placeholder="last name ..."
								value={this.state.last_name}
								onChange={this.changing}
							/>
						</div>
						<div style={div_style}>
							<input
								type="text"
								name="phone_num"
								style={{ flex: '10', padding: '10px', width: "30vw"}}
								placeholder="phone number ..."
								value={this.state.phone_num}
								onChange={this.changing}
							/>
						</div>
						<div style={div_style}>
							<input
								type="text"
								name="email_num"
								style={{ flex: '10', padding: '10px', width: "30vw"}}
								placeholder="email ..."
								value={this.state.email_num}
								onChange={this.changing}
							/>
						</div>
						<div className = "flex">
							<input
								type="submit"
								value="submit"
								className="btn_submit"
								style={{flex: '1'}}
							/>
						</div>
				</div>
			</div>
			</form>
		)
	}
	on_submit = (e) =>
	{
		e.preventDefault();
		this.props.adding_contacts(this.state.first_name);
		this.props.adding_contacts(this.state.last_name);
		this.props.adding_contacts(this.state.phone_num);
		this.props.adding_contacts(this.state.email_num);
		
		// set the value back to empty after submitting
		this.setState({ first_name: ''});
		this.setState({ last_name: ''});
		this.setState({ phone_num: ''});
		this.setState({ email_num: ''});
	}

	// helps take input
	changing = (e) => this.setState(
	{
		// it can take is multiple values if necessary
		[e.target.name]:  e.target.value});
}

// helps space the paddings
const div_style =
{
	padding: '30px',
}
const get_style =
{
	borderBottom: '4px #ccc dotted',
	background: 'lightgrey',
	padding: '10px',
	height: '100vh',
	width: '100vw'
}
export default ADD_CONTACTS
