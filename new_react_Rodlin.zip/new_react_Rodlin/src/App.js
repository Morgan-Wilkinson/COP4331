import React, { Component } from 'react';
import CONTACT_MANAGER from './components/contact_manager';
import PROFILE from './components/profile';
import Header from './components/layouts/header';
import ADD_CONTACTS from './components/add_contacts';
import uuid from 'uuid';
import './App.css';

//var wide = window.innerWidth; var long = window.innerHeight;
class App extends Component
{
  constructor(e)
  {
    super(e)
    this.we_are_editing = false;
  }
  state =
  {
    cur_contacts:
    [
      {
        // uuid gives us a unique and random id
        // completed checks if they have been selected
        id: uuid.v4(),
        first_name: 'John',
        last_name: 'Smith',
        phone_num: '9541119449',
        email_num: 'john@mail.com',
        completed: false,
        edited: false
      },
      {
        id: uuid.v4(),
        first_name: 'Paul',
        last_name: 'Clyde',
        phone_num: '7542225555',
        email_num: 'paul@mail.com',
        completed: false,
        edited: false
      },
      {
        id: uuid.v4(),
        first_name: 'Evelyn',
        last_name: 'Mars',
        phone_num: '4543337777',
        email_num: 'evelyn@mail.com',
        completed: false,
        edited: false
      },
    ]
  }

  render()
  {
    //float to the right helped in keeping the second div at the top
    console.log(this.state.cur_contacts);
    console.log("length is"+this.state.cur_contacts[0].edited)

    for (let i = 0; i < this.state.cur_contacts.length; i++)
    {
      //if we editing then we will show the edit page
      if (this.state.cur_contacts[i].edited === true)
      this.we_are_editing = true
      console.log("is this edited "+this.state.cur_contacts[i].edited)
      console.log (this.we_are_editing)
    }
    if ( this.we_are_editing === false)
    {
      return (
        <div className="App">
          <Header/>
          <div className = "container"
          style={{height: '100vh', background: "GhostWhite"}}>
            <CONTACT_MANAGER cur_contacts={this.state.cur_contacts}
            mark_check={this.mark_check}
            />
          </div>
          <div className = "container"
          style={{float:'right', height: '100vh', background: "CadetBlue"}}>
            <PROFILE cur_contacts={this.state.cur_contacts}
            delete_check={this.delete_check}
            editing_contacts ={this.editing_contacts}
            />
          </div>
        </div>
      );
    }
    else
    {
      // this section makes it so you
      // won't be able to interact with contact list as you edit
      // a contact info
      return (
        <div className="App">
          <Header/>
          <div className = "container"
          style={{height: '100vh', background: "GhostWhite"}}>
            <CONTACT_MANAGER cur_contacts={this.state.cur_contacts}
            mark_check={this.mark_check}
            />
          </div>
          <div className = "container"
          style={{float:'right', height: '100vh', background: "CadetBlue"}}>
            <EDIT_CONTACTS editing_contacts={this.adding_contacts}/>
            <ADD_CONTACTS adding_contacts={this.adding_contacts}/>
          </div>
        </div>
      );
    }
  }

  // this connects to the edit button
  // sets our state to editing mode
  editing_contacts = (id) =>
  {
    console.log("editing contacts")
    this.setState({cur_contacts: this.state.cur_contacts.map(manager =>
    {

      if(manager.id === id)
      {
        manager.edited = !manager.edited;
      }
      return(manager);
    })});
  }
  // the info were passing to new contacts
  adding_contacts = (first_name) =>
	{
    console.log("adding contacts")
		const new_stuff_todo =
		{
			id: uuid.v4(),
			first_name: first_name, //or just "title"
      completed: false,
      edited: false
		}
		this.setState({cur_contacts:
		[...this.state.cur_contacts, new_stuff_todo]});
	}

  // this connects to our info button
  // info will show up as long as we are not
  // in edit mode
  mark_check = (id) =>
  {
    console.log("mark check")
    console.log(this.we_are_editing)
    if (this.we_are_editing === false)
    {
      console.log("inside if statement")
      //setState is an inbuilt thing so I have to use it in camelcase
      this.setState({cur_contacts: this.state.cur_contacts.map(manager =>
      {

        if(manager.id === id)
        {
          manager.completed = !manager.completed;
        }
        return(manager);
      })});
    }
    //console.log(id); // just to check which id its on
  }

  delete_check = (id) =>
  {
    // spread filter "..."
    this.setState({cur_contacts:
    [...this.state.cur_contacts.filter(manager => manager.id !== id)]});
    console.log(id);
  }
}

export default App;
