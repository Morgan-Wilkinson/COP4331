import React, { Component } from 'react';
import CONTACT_MANAGER from './components/contact_manager';
import PROFILE from './components/profile';
import Header from './components/layouts/header';
import ADD_CONTACTS from './components/add_contacts';
import uuid from 'uuid';
import './App.css';


var wide = window.innerWidth; var long = window.innerHeight;
class App extends Component
{
  state =
  {
    cur_contacts:
    [
      {
        // uuid gives us a unique and random id
        // completed checks if they have been selected
        id: uuid.v4(),
        first_name: 'John',
        last_name: 'Smith',
        phone_num: '9541119999',
        email_num: 'john@mail.com',
        completed: false
      },
      {
        id: uuid.v4(),
        first_name: 'Paul',
        last_name: 'Clyde',
        phone_num: '7542225555',
        email_num: 'paul@mail.com',
        completed: false
      },
      {
        id: uuid.v4(),
        first_name: 'Evelyn',
        last_name: 'Mars',
        phone_num: '4543337777',
        email_num: 'evelyn@mail.com',
        completed: false
      },
    ]
  }

  render()
  {
    //float to the right helped in keeping the second div at the top
    console.log(this.state.cur_contacts);
    return (

      <div className="App">
        <Header/>
        <div className = "container"
        style={{height: '100vh', background: "GhostWhite"}}>
          <CONTACT_MANAGER cur_contacts={this.state.cur_contacts}
          mark_check={this.mark_check}
          />
        </div>
        <div className = "container"
        style={{float:'right', height: '100vh', background: "CadetBlue"}}>
          <PROFILE cur_contacts={this.state.cur_contacts}
          delete_check={this.delete_check}/>
          <ADD_CONTACTS adding_contacts={this.adding_contacts}/>
        </div>
      </div>
    );
  }

  adding_contacts = (first_name) =>
	{
		const new_stuff_todo =
		{
			id: uuid.v4(),
			first_name: first_name, //or just "title"
			completed: false
		}
		this.setState({cur_contacts:
		[...this.state.cur_contacts, new_stuff_todo]});
		//checking id

	}

  mark_check = (id) =>
  {
    //setState is an inbuilt thing so I have to use it in camelcase
    this.setState({cur_contacts: this.state.cur_contacts.map(manager =>
    {

      if(manager.id === id)
      {
        manager.completed = !manager.completed;
      }
      return(manager);
    })});
    console.log(id); // just to check which id its on
  }

  delete_check = (id) =>
  {
    // spread filter "..."
    this.setState({cur_contacts:
    [...this.state.cur_contacts.filter(manager => manager.id !== id)]});
    console.log(id);
  }
}

const get_style =
{
  // need to get this done later
  //width: wide/2,
  //height: long
}

export default App;
